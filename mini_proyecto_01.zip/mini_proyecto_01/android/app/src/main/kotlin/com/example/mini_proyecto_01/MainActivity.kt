package com.example.mini_proyecto_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
